// 后台存档任务（跑在 offscreen 页面里）：弹窗关掉、切走标签页都不会中断。
// 任务排队一个个跑，进度通过 runtime 消息广播给弹窗、弹幕库页面和工具栏角标。

const { db } = BDA;
const fmtNum = (n) => (n || 0).toLocaleString('zh-CN');

const state = {
  running: false,
  status: '',
  current: null,     // { cid, label }
  queued: 0,
  log: [],           // { text, cls, at, cid }
  addedThisRun: 0,
  finishedAt: 0,
  version: 0,
};
const queue = [];
const pendingMerges = []; // 存完后要合并的 { title, sources }
let abort = null;

function broadcast() {
  state.version++;
  state.queued = queue.length;
  chrome.runtime.sendMessage({ type: 'job-state', state }).catch(() => {});
}

function addLog(text, cls, cid) {
  state.log.push({ text, cls: cls || '', at: Date.now(), cid });
  if (state.log.length > 200) state.log.splice(0, state.log.length - 200);
  broadcast();
}

let lastStatusAt = 0;
function setStatus(s) {
  state.status = s;
  // 下载完整弹幕时状态变得很快，别每次都广播
  if (Date.now() - lastStatusAt > 200) { lastStatusAt = Date.now(); broadcast(); }
}

function enqueue(tasks, merge) {
  // merge 可以是一个，也可以是一组（按集分别合并时每集一个）
  if (merge) pendingMerges.push(...(Array.isArray(merge) ? merge : [merge]));
  // 已经在排队的同一个分P不重复加
  for (const t of tasks) {
    if (queue.some((q) => q.meta.cid === t.meta.cid) || (state.current && state.current.cid === t.meta.cid)) continue;
    queue.push(t);
  }
  if (!state.running) run();
  else broadcast();
}

async function run() {
  state.running = true;
  state.addedThisRun = 0;
  state.log = [];
  abort = new AbortController();
  let login = null;
  const touched = new Set();
  broadcast();

  while (queue.length) {
    const { meta, history } = queue.shift();
    touched.add(meta.cid);
    const label = meta.partsTotal > 1 ? `${meta.groupTitle} · P${meta.page} ${meta.part}` : meta.groupTitle;
    state.current = { cid: meta.cid, label };
    try {
      const list = await BDA.fetchCurrent(meta.cid, meta.duration, setStatus, abort.signal);
      const r = await db.merge(meta, list, '当前弹幕池');
      state.addedThisRun += r.added;
      addLog(`${label}：新增 ${fmtNum(r.added)} 条，共 ${fmtNum(r.total)} 条`, 'ok', meta.cid);

      if (history) {
        if (!login) login = await BDA.getLogin();
        if (!login.isLogin) {
          addLog(`${label}：没登录 B 站，没法下载完整弹幕，只存了现在的`, 'err', meta.cid);
        } else {
          const existing = await db.getVideo(meta.cid);
          let histAdded = 0;
          const res = await BDA.fetchHistory(meta.cid, meta.pubTs, existing.historyDates,
            (s) => setStatus(`${s}（已补回 ${fmtNum(histAdded)} 条）`),
            abort.signal,
            async (date, got, final) => {
              const m = await db.merge(meta, got, null);
              histAdded += m.added;
              state.addedThisRun += m.added;
              if (final) await db.markHistoryDate(meta.cid, date);
            });
          await db.appendLog(meta.cid, { added: histAdded, note: `完整弹幕 ${res.days} 天` });
          const after = await db.getVideo(meta.cid);
          addLog(res.days
            ? `${label}：下载完整弹幕，补回 ${fmtNum(histAdded)} 条被挤掉的，共 ${fmtNum(after.count)} 条`
            : `${label}：完整弹幕已经是最新的`, 'ok', meta.cid);
        }
      }
    } catch (e) {
      if (e.name === 'AbortError') {
        queue.length = 0;
        addLog('已取消。已经拉到的部分都存好了。', 'err');
        break;
      }
      addLog(`${label}：失败 — ${e.message}`, 'err', meta.cid);
    }
  }

  // 存完了：先做这次要求的合并，再把用到这些分P的旧合并版重新拼
  try {
    const built = new Set();
    while (pendingMerges.length) {
      const m = pendingMerges.shift();
      setStatus(`合并「${m.title}」`);
      const r = await BDA.buildMerged(m);
      built.add(r.cid);
      addLog(`已合并成「${m.title}」：${m.sources.length} 段，共 ${fmtNum(r.total)} 条弹幕` +
        (r.missing.length ? `（${r.missing.length} 段没存到，跳过了）` : ''), r.missing.length ? 'err' : 'ok', r.cid);
    }
    for (const r of await BDA.rebuildAffected([...touched])) {
      if (built.has(r.cid)) continue;
      addLog(`合并版「${r.title}」已跟着更新，共 ${fmtNum(r.total)} 条`, 'ok', r.cid);
    }
  } catch (e) {
    addLog(`合并失败 — ${e.message}`, 'err');
  }

  state.running = false;
  state.current = null;
  state.status = `完成，这次一共新增 ${fmtNum(state.addedThisRun)} 条弹幕。`;
  state.finishedAt = Date.now();
  abort = null;
  broadcast();
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'runner-enqueue') {
    enqueue(msg.tasks, msg.merge);
    sendResponse({ ok: true });
  } else if (msg.type === 'job-get') {
    sendResponse(state);
  } else if (msg.type === 'job-cancel') {
    queue.length = 0;
    if (abort) abort.abort();
    sendResponse({ ok: true });
  }
});
