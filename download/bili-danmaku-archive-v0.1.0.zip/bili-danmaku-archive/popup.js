// 工具栏弹窗：当前视频一键存档，或者粘贴链接直接存（不用打开视频页）。
// 真正的下载在后台跑，弹窗关掉也不会中断。

const { h, fmtNum } = BDA;
const $ = (s) => document.querySelector(s);
const openTab = (path) => { chrome.tabs.create({ url: chrome.runtime.getURL(path) }); window.close(); };

let shown = null; // { video, opts } 当前卡片显示的视频，任务完成后刷新“已存”标记

async function savedMap() {
  return new Map((await BDA.db.listVideos()).map((v) => [v.cid, v]));
}

async function show(text, tabTitle) {
  const box = $('#video');
  box.replaceChildren(h('div', { class: 'hint' }, '正在读取视频信息…'));
  const res = await BDA.lookup(text, tabTitle);
  if (!res.video) {
    const saved = res.gone && res.key ? (await BDA.db.listVideos()).filter((v) => v.groupKey === res.key) : [];
    box.replaceChildren(h('div', { class: 'hint err' },
      res.error,
      saved.length ? h('div', {}, h('br'), `不过你的弹幕库里有它的存档（${fmtNum(saved.reduce((s, v) => s + v.count, 0))} 条）。`,
        h('br'), h('button', { class: 'small', onclick: () => openTab(`library.html?q=${encodeURIComponent(res.key)}`) }, '去弹幕库看')) : null));
    return;
  }
  shown = { video: res.video, opts: res.opts, warnings: res.warnings };
  await renderShown();
}

async function renderShown() {
  if (!shown) return;
  const { video, opts, warnings } = shown;
  $('#video').replaceChildren(
    warnings && warnings.length ? h('div', { class: 'hint err' }, `有 ${warnings.length} 个链接没查到：\n${warnings.join('\n')}`) : '',
    BDA.renderPicker(video, await savedMap(), Object.assign({ onStart: start }, opts)));
}

async function refreshShown() {
  const picker = $('#video .picker');
  if (picker && picker.refreshSaved) picker.refreshSaved(await savedMap());
}

async function start(tasks, merge) {
  const r = await BDA.jobs.start(tasks, merge);
  if (r && !r.ok) alert(r.error);
}

function renderJob(state) {
  const box = $('#job');
  if (!state || (!state.running && !state.finishedAt)) { box.hidden = true; return; }
  box.hidden = false;
  box.classList.toggle('running', state.running);
  box.replaceChildren(...BDA.renderJob(state, { maxLog: 4 }));
}

let lastVersion = -1, lastLogLen = 0;
BDA.jobs.onState((state) => {
  if (state.version <= lastVersion) return;
  lastVersion = state.version;
  renderJob(state);
  if (state.log.length !== lastLogLen || !state.running) { lastLogLen = state.log.length; refreshShown(); refreshCount(); }
});

$('#lookupForm').addEventListener('submit', (e) => {
  e.preventDefault();
  const v = $('#lookupInput').value.trim();
  if (v) show(v);
});
BDA.autoGrowInput($('#lookupInput'), $('#lookupForm'));

$('#openLibrary').addEventListener('click', () => openTab('library.html'));
$('#openPlayer').addEventListener('click', () => openTab('player.html'));

async function refreshCount() {
  const videos = await BDA.db.listVideos();
  $('#libCount').textContent = videos.length ? `（${new Set(videos.map((v) => v.groupKey)).size}）` : '';
}

(async function init() {
  chrome.runtime.sendMessage({ type: 'badge-clear' }).catch(() => {});
  refreshCount();
  BDA.getLogin().then((l) => {
    const pill = $('#login');
    pill.className = 'pill ' + (l.isLogin ? 'ok' : 'warn');
    pill.textContent = l.isLogin ? l.uname : '未登录 B 站';
    pill.title = l.isLogin ? '已登录，可以下载完整弹幕' : '能存现在的弹幕；下载完整弹幕需要先在这个浏览器里登录 B 站';
  });
  renderJob(await BDA.jobs.get());

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab && tab.url && BDA.parseTarget(tab.url) && /bilibili\.com|b23\.tv/.test(tab.url)) {
    show(tab.url, tab.title);
  } else if (tab && tab.url && /^https:\/\/www\.youtube\.com\//.test(tab.url)) {
    $('#video').replaceChildren(h('div', { class: 'hint' },
      '在 YouTube 播放器右下角点「弹」按钮，选一份弹幕库里的存档，弹幕就会叠在这个视频上。',
      h('br'), '（装好或更新插件后，已经打开的 YouTube 页面要刷新一下才有这个按钮）'));
  } else {
    $('#video').replaceChildren(h('div', { class: 'hint' }, '在 B 站视频页打开这个弹窗会自动认出视频；也可以在上面粘贴链接直接存。'));
  }
})();
