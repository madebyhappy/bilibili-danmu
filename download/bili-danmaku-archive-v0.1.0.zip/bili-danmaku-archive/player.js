// 本地播放器：本地视频文件 + 存档弹幕，用 canvas 画在视频上面。
// 弹幕位置完全由 video.currentTime 算出来，所以暂停、拖进度条、倍速都自然对得上。

const $ = (s) => document.querySelector(s);
const video = $('#video'), canvas = $('#canvas'), stage = $('#stage');
const ctx = canvas.getContext('2d');
const params = new URLSearchParams(location.search);

let settings = BDA.loadSettings();
let danmaku = [];        // 原始弹幕
let items = [];          // 排好版的
let maxLife = 10;
let box = { x: 0, y: 0, w: 0, h: 0 }; // 视频画面在 stage 里的实际区域（去掉黑边）
let dpr = 1;
let on = true;
let measure = BDA.canvasMeasurer(settings.font);

// ───────────── 选视频 ─────────────

function openVideo(file) {
  if (!file) return;
  if (video.src) URL.revokeObjectURL(video.src);
  video.src = URL.createObjectURL(file);
  $('#videoName').textContent = file.name;
  $('#videoName').title = file.name;
  $('#drop').hidden = true;
  video.play().catch(() => {});
}

$('#pickVideo').addEventListener('click', () => $('#videoFile').click());
$('#changeVideo').addEventListener('click', () => $('#videoFile').click());
$('#videoFile').addEventListener('change', (e) => openVideo(e.target.files[0]));
for (const el of [stage, $('#drop')]) {
  el.addEventListener('dragover', (e) => { e.preventDefault(); $('#drop').classList.add('over'); });
  el.addEventListener('dragleave', () => $('#drop').classList.remove('over'));
  el.addEventListener('drop', (e) => {
    e.preventDefault();
    $('#drop').classList.remove('over');
    // 视频、字幕、弹幕可以一起拖进来
    for (const f of e.dataTransfer.files) {
      if (isVideo(f)) openVideo(f);
      else loadUserFile(f);
    }
  });
}
const isVideo = (f) => f.type.startsWith('video/') || /\.(mkv|mp4|webm|mov|m4v|avi|flv|ts)$/i.test(f.name);
video.addEventListener('error', () => {
  $('#videoName').textContent = '这个视频格式浏览器播不了（可以先转成 mp4，或者导出 ASS 用本地播放器看）';
});

// ───────────── 弹幕轨道（可以同时加好几份） ─────────────
// 比如两个 UP 主各传了一份同一部剧，两边的弹幕可以一起看。
// 每份弹幕单独开关、单独调“从视频第几秒开始”（每个来源单独记住），排版时合在一起，互相不重叠。

let tracks = [];   // [{ key, label, list, offset, on }]
let libVideos = [];

const TRACK_COLORS = ['#fb7299', '#00a1d6', '#f5a623', '#16a34a', '#8b5cf6'];

// 从弹幕库添加：点按钮展开选择列表（按视频折叠，最近存的在前），选完自动收起
async function fillSources() {
  libVideos = await BDA.db.listVideos();
  const box = $('#libPicker');
  if (box.hidden) return;
  box.replaceChildren(BDA.renderArchivePicker({
    videos: libVideos,
    disabled: new Set(tracks.filter((t) => t.key.startsWith('cid:')).map((t) => Number(t.key.slice(4)))),
    onPick: async (cid) => {
      box.hidden = true;
      $('#addFromLib').classList.remove('open');
      await addCid(cid);
    },
  }));
}

$('#addFromLib').addEventListener('click', () => {
  const box = $('#libPicker');
  box.hidden = !box.hidden;
  $('#addFromLib').classList.toggle('open', !box.hidden);
  fillSources();
});

// 选择列表的样式（和 YouTube / B 站面板共用一份）
document.head.append(Object.assign(document.createElement('style'), { textContent: BDA.archivePickerCSS }));

function trackLabel(v) {
  if (v.kind === 'merged') return `合并版 · ${v.groupTitle}`;
  if (v.kind === 'import') return v.part;
  return v.partsTotal > 1 ? `${v.groupTitle} · P${v.page} ${v.part}` : v.groupTitle;
}

async function addCid(cid) {
  const v = libVideos.find((x) => x.cid === cid) || await BDA.db.getVideo(cid);
  if (!v) return;
  addTrack(await BDA.db.getDanmaku(cid), 'cid:' + cid, trackLabel(v));
}


$('#loadFile').addEventListener('click', () => $('#dmFile').click());
$('#dmFile').addEventListener('change', (e) => { loadUserFile(e.target.files[0]); e.target.value = ''; });
$('#loadSubs').addEventListener('click', () => $('#subFile').click());
$('#subFile').addEventListener('change', (e) => { loadUserFile(e.target.files[0]); e.target.value = ''; });

// 用户自己的文件：字幕（.srt/.vtt/.ass/.ssa）或弹幕（.xml/.json/弹幕 .ass），按内容自动分
async function loadUserFile(f) {
  if (!f) return;
  try {
    const r = await BDA.readUserFile(f);
    if (!r) return alert(`「${f.name}」不是能识别的文件。字幕支持 .srt .vtt .ass .ssa，弹幕支持 .xml .json 和弹幕 .ass。`);
    if (r.kind === 'subs') {
      if (!r.cues.length) return alert(`「${f.name}」里没读到字幕。`);
      setSubs(r.cues, f.name);
      showPane('sub');
    } else {
      if (!r.list.length) return alert(`「${f.name}」里没读到弹幕。`);
      if (r.parts > 1) alert(`这个备份里有 ${r.parts} 个分P，先加载第一个。想选别的，可以先在弹幕库里导入。`);
      addTrack(r.list, 'file:' + f.name, f.name);
    }
  } catch (err) {
    alert(`加载失败：${err.message}`);
  }
}

function addTrack(list, key, label) {
  if (tracks.some((t) => t.key === key)) return;
  tracks.push({ key, label, list, offset: loadOffset(key), on: true });
  rebuild();
}

function removeTrack(key) {
  tracks = tracks.filter((t) => t.key !== key);
  rebuild();
}

// 把打开的轨道按各自的开始时间平移后合成一份，交给排版
function rebuild() {
  const live = tracks.filter((t) => t.on && t.list.length);
  if (live.length === 1 && !live[0].offset) {
    danmaku = live[0].list;
  } else {
    danmaku = [];
    for (const t of live) {
      if (!t.offset) danmaku.push(...t.list);
      else for (const d of t.list) danmaku.push(Object.assign({}, d, { t: d.t + t.offset }));
    }
    danmaku.sort((a, b) => a.t - b.t);
  }
  renderTracks();
  fillSources();
  relayoutSoon();
}

function renderTracks() {
  const box = $('#tracks');
  box.replaceChildren(...tracks.map((t, i) => {
    const color = TRACK_COLORS[i % TRACK_COLORS.length];
    const on = Object.assign(document.createElement('input'), { type: 'checkbox', checked: t.on, title: '开 / 关这份弹幕' });
    on.addEventListener('change', () => { t.on = on.checked; rebuild(); });
    const input = Object.assign(document.createElement('input'), {
      type: 'text', value: fmtClock(t.offset), inputMode: 'numeric',
      title: '这份弹幕从视频的这个时间开始出现。分:秒；↑↓ 键每次 0.5 秒，按住 Shift 每次 5 秒',
    });
    const coverage = document.createElement('div');
    coverage.className = 'coverage muted small';
    const showCoverage = () => {
      const last = t.list.length ? t.list[t.list.length - 1].t : 0;
      coverage.textContent = `出现在视频的 ${fmtClock(Math.max(0, t.offset))} – ${fmtClock(t.offset + last)}`;
    };
    const setOffset = (sec) => {
      t.offset = Math.round(sec * 10) / 10;
      saveOffset(t.key, t.offset);
      input.value = fmtClock(t.offset);
      showCoverage();
      rebuildSoon();
    };
    input.addEventListener('change', () => {
      const v = parseClock(input.value);
      if (v == null) input.value = fmtClock(t.offset); else setOffset(v);
    });
    const arrows = document.createElement('span');
    arrows.className = 'arrows';
    for (const [dir, txt, tip] of [[1, '▲', '晚 0.5 秒'], [-1, '▼', '早 0.5 秒']]) {
      const b = Object.assign(document.createElement('button'), { type: 'button', textContent: txt, title: tip });
      b.dataset.dir = dir;
      arrows.append(b);
    }
    const stepperEl = document.createElement('span');
    stepperEl.className = 'stepper';
    stepperEl.append(input, arrows);
    stepper(stepperEl, input, () => t.offset, setOffset);
    const here = Object.assign(document.createElement('button'), { className: 'small', textContent: '从这里', title: '从视频当前播放的位置开始' });
    here.addEventListener('click', () => setOffset(video.currentTime || 0));
    const remove = Object.assign(document.createElement('button'), { className: 'small danger', textContent: '✕', title: '去掉这份弹幕' });
    remove.addEventListener('click', () => removeTrack(t.key));

    const head = document.createElement('div');
    head.className = 'track-head';
    const name = Object.assign(document.createElement('span'), { className: 'name', textContent: t.label, title: t.label });
    const count = Object.assign(document.createElement('span'), { className: 'muted small', textContent: `${t.list.length.toLocaleString('zh-CN')} 条` });
    head.append(on, name, count, remove);
    const row = document.createElement('div');
    row.className = 'start-row';
    row.append('从视频的', stepperEl, '开始', here);
    const el = document.createElement('div');
    el.className = 'track' + (t.on ? '' : ' off');
    el.style.setProperty('--track', color);
    el.append(head, row, coverage);
    showCoverage();
    return el;
  }));
  $('#tracksHint').hidden = tracks.length < 1;
}

let rebuildTimer = 0;
function rebuildSoon() {
  clearTimeout(rebuildTimer);
  rebuildTimer = setTimeout(() => {
    // 只重新合成和排版，不重画轨道列表（不然正在按住的 ▲▼ 会断）
    const keepRender = renderTracks;
    renderTracks = () => {};
    rebuild();
    renderTracks = keepRender;
  }, 120);
}

// ───────────── 每个来源单独记住的开始时间 ─────────────

function loadOffset(key) {
  if (!key) return 0;
  try { return Number(JSON.parse(localStorage.getItem('bda-offsets') || '{}')[key]) || 0; } catch { return 0; }
}

function saveOffset(key, value) {
  if (!key) return;
  try {
    const all = JSON.parse(localStorage.getItem('bda-offsets') || '{}');
    if (value) all[key] = value; else delete all[key];
    localStorage.setItem('bda-offsets', JSON.stringify(all));
  } catch { /* 记不住就只在本次生效 */ }
}

function fmtClock(sec) {
  const neg = sec < 0;
  sec = Math.abs(Math.round(sec * 10) / 10);
  const h = Math.floor(sec / 3600), m = Math.floor(sec / 60) % 60, s = sec % 60;
  const ss = (s < 10 ? '0' : '') + (Number.isInteger(s) ? s : s.toFixed(1));
  return (neg ? '-' : '') + (h ? `${h}:${String(m).padStart(2, '0')}:${ss}` : `${m}:${ss}`);
}

// "50:00" / "1:02:30" / "90" / "-0:05" → 秒
function parseClock(text) {
  const t = text.trim().replace(/：/g, ':');
  const neg = t.startsWith('-');
  const parts = t.replace(/^-/, '').split(':').map(Number);
  if (!parts.length || parts.some((n) => !isFinite(n))) return null;
  const sec = parts.reduce((acc, n) => acc * 60 + n, 0);
  return neg ? -sec : sec;
}

// 上下箭头的调节框（像 IINA 的字幕延迟）：点一下 / 按一下 ↑↓ = 0.5 秒，Shift = 5 秒，按住会连续调
function stepper(root, input, getValue, setValue) {
  const bump = (dir, big) => setValue(getValue() + dir * (big ? 5 : 0.5));
  root.querySelectorAll('[data-dir]').forEach((btn) => {
    let timer = 0, repeat = 0;
    const stop = () => { clearTimeout(timer); clearInterval(repeat); };
    btn.addEventListener('pointerdown', (e) => {
      e.preventDefault();
      const dir = Number(btn.dataset.dir), big = e.shiftKey;
      bump(dir, big);
      timer = setTimeout(() => { repeat = setInterval(() => bump(dir, big), 80); }, 400);
    });
    btn.addEventListener('pointerup', stop);
    btn.addEventListener('pointerleave', stop);
  });
  input.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {
      e.preventDefault();
      bump(e.key === 'ArrowUp' ? 1 : -1, e.shiftKey);
    }
  });
}

// ───────────── 字幕 ─────────────
// 画在视频画面底部的一个 div 里；时间可以单独调（字幕文件和视频对不上时用），每个字幕文件单独记住。

const subsEl = $('#subs');
let subs = [], subKey = null, subOffset = 0, subShown = '';

function setSubs(cues, name) {
  subs = cues;
  subKey = name ? 'sub:' + name : null;
  subOffset = loadOffset(subKey);
  $('#subName').textContent = name || '';
  $('#subLoaded').hidden = !name;
  showSubOffset();
}

function setSubOffset(sec) {
  subOffset = Math.round(sec * 10) / 10;
  saveOffset(subKey, subOffset);
  showSubOffset();
}

function showSubOffset() {
  $('#subDelay').value = (subOffset > 0 ? '+' : '') + subOffset + 's';
  $('#subOffset').textContent = !subOffset ? '和视频同步'
    : subOffset > 0 ? `字幕晚 ${subOffset} 秒出现` : `字幕早 ${-subOffset} 秒出现`;
}

// 当前时间该显示的字幕（可能同时有几条，比如双语）
function activeSubs(now) {
  const t = now - subOffset;
  let lo = 0, hi = subs.length;
  while (lo < hi) { const mid = (lo + hi) >> 1; if (subs[mid].start <= t) lo = mid + 1; else hi = mid; }
  const out = [];
  for (let i = lo - 1; i >= 0 && i >= lo - 30; i--) if (subs[i].end > t) out.unshift(subs[i].text);
  return out.join('\n');
}

function placeSubs(rect) {
  subsEl.style.left = box.x + 'px';
  subsEl.style.width = box.w + 'px';
  subsEl.style.bottom = (rect.height - box.y - box.h + box.h * 0.05) + 'px';
  subsEl.style.fontSize = (settings.subSize * box.h / 1080) + 'px';
}

$('#unloadSubs').addEventListener('click', () => setSubs([], null));
$('#subZero').addEventListener('click', () => setSubOffset(0));
stepper($('#subStepper'), $('#subDelay'), () => subOffset, setSubOffset);
$('#subDelay').addEventListener('change', () => {
  const v = parseFloat($('#subDelay').value.replace(/[s秒\s]/g, ''));
  if (isFinite(v)) setSubOffset(v); else showSubOffset();
});

// ───────────── 排版 + 绘制 ─────────────

function relayout() {
  const rect = stage.getBoundingClientRect();
  dpr = window.devicePixelRatio || 1;
  canvas.width = Math.round(rect.width * dpr);
  canvas.height = Math.round(rect.height * dpr);
  canvas.style.width = rect.width + 'px';
  canvas.style.height = rect.height + 'px';
  // object-fit: contain 之后画面实际所在的区域
  const vw = video.videoWidth || 16, vh = video.videoHeight || 9;
  const s = Math.min(rect.width / vw, rect.height / vh);
  box = { w: vw * s, h: vh * s, x: (rect.width - vw * s) / 2, y: (rect.height - vh * s) / 2 };
  placeSubs(rect);
  items = danmaku.length ? BDA.layout(danmaku, box.w, box.h, settings, measure) : [];
  maxLife = Math.max(settings.scrollTime, settings.fixTime);
  $('#dmStat').textContent = danmaku.length
    ? `${danmaku.length.toLocaleString('zh-CN')} 条弹幕${items.length < danmaku.length ? `，显示 ${items.length.toLocaleString('zh-CN')} 条` : ''}`
    : '';
}

// 找第一个 t >= x 的位置
function lowerBound(x) {
  let lo = 0, hi = items.length;
  while (lo < hi) {
    const mid = (lo + hi) >> 1;
    if (items[mid].t < x) lo = mid + 1; else hi = mid;
  }
  return lo;
}

function draw() {
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  const subText = settings.showSubs && subs.length ? activeSubs(video.currentTime) : '';
  if (subText !== subShown) { subShown = subText; subsEl.textContent = subText; }
  if (on && items.length) {
    const now = video.currentTime;
    ctx.setTransform(dpr, 0, 0, dpr, box.x * dpr, box.y * dpr);
    ctx.globalAlpha = settings.opacity;
    ctx.textBaseline = 'top';
    ctx.lineJoin = 'round';
    ctx.lineWidth = Math.max(2, box.h / 400);
    let lastFont = '';
    for (let i = lowerBound(now - maxLife); i < items.length; i++) {
      const it = items[i];
      if (it.t > now) break;
      if (now >= it.end) continue;
      const x = it.kind === 'scroll' ? box.w - (now - it.t) * it.v : (box.w - it.w) / 2;
      const font = `${it.size}px "${settings.font}", "PingFang SC", "Microsoft YaHei", sans-serif`;
      if (font !== lastFont) { ctx.font = font; lastFont = font; }
      const c = it.dm.c & 0xffffff;
      const r = c >> 16, g = (c >> 8) & 0xff, b = c & 0xff;
      ctx.strokeStyle = 0.299 * r + 0.587 * g + 0.114 * b < 60 ? 'rgba(255,255,255,.9)' : 'rgba(0,0,0,.75)';
      ctx.fillStyle = '#' + c.toString(16).padStart(6, '0');
      ctx.strokeText(it.text, x, it.y);
      ctx.fillText(it.text, x, it.y);
    }
  }
  requestAnimationFrame(draw);
}

new ResizeObserver(() => relayout()).observe(stage);
video.addEventListener('loadedmetadata', relayout);

// ───────────── 控制面板 ─────────────

function bindControls() {
  document.querySelectorAll('[data-key]').forEach((el) => {
    const key = el.dataset.key;
    if (el.type === 'checkbox') el.checked = !!settings[key];
    else el.value = settings[key];
    showValue(key);
    const ev = el.tagName === 'TEXTAREA' || el.type === 'number' ? 'change' : 'input';
    el.addEventListener(ev, () => {
      settings[key] = el.type === 'checkbox' ? el.checked
        : el.tagName === 'TEXTAREA' ? el.value
        : Number(el.value);
      showValue(key);
      BDA.saveSettings(settings);
      relayoutSoon();
    });
  });
  $('#on').addEventListener('change', (e) => (on = e.target.checked));
}

function showValue(key) {
  const out = document.querySelector(`output[data-for=${key}]`);
  if (!out) return;
  const v = settings[key];
  out.textContent = key === 'opacity' ? Math.round(v * 100) + '%'
    : key === 'area' ? (v >= 1 ? '全屏' : `上 ${Math.round(v * 100)}%`)
    : key === 'scrollTime' ? v + ' 秒' : v + ' px';
}

let relayoutTimer = 0;
function relayoutSoon() {
  clearTimeout(relayoutTimer);
  relayoutTimer = setTimeout(relayout, 120);
}

// ───────────── 倍速 ─────────────
// 弹幕位置按 video.currentTime 算，倍速时弹幕自然跟着快慢，不用额外处理。记住上次用的倍速。

const RATES = [0.5, 0.75, 1, 1.25, 1.5, 2, 3];

function setRate(r) {
  video.playbackRate = r;
  try { localStorage.setItem('bda-rate', String(r)); } catch { /* 记不住就算了 */ }
}

function showRate() {
  document.querySelectorAll('#speed [data-rate]').forEach((b) =>
    b.classList.toggle('active', Number(b.dataset.rate) === video.playbackRate));
}

function stepRate(dir) {
  const i = RATES.findIndex((r) => r >= video.playbackRate - 1e-6);
  setRate(RATES[Math.max(0, Math.min(RATES.length - 1, (i < 0 ? RATES.length - 1 : i) + dir))]);
}

document.querySelectorAll('#speed [data-rate]').forEach((b) => b.addEventListener('click', () => setRate(Number(b.dataset.rate))));
// 原生控制条（⋮ 菜单里的播放速度）改的也同步显示
video.addEventListener('ratechange', showRate);
// 换视频时浏览器会把倍速重置成 1，读回上次的
video.addEventListener('loadedmetadata', () => {
  let r = 1;
  try { r = Number(localStorage.getItem('bda-rate')) || 1; } catch { /* 用 1 */ }
  setRate(r);
});
showRate();

// ───────────── 全屏 + 快捷键 ─────────────

// 全屏：整个画面（视频 + 弹幕 + 字幕）进系统全屏。视频自带控制条里的全屏只会把视频本身放大、弹幕跟不过去，所以那个是灰的。
// 网页全屏：画面铺满浏览器窗口，不进系统全屏，方便同时开别的窗口。
function toggleFullscreen() {
  if (document.fullscreenElement) document.exitFullscreen();
  else stage.requestFullscreen();
}

function toggleWebFullscreen(force) {
  const on = typeof force === 'boolean' ? force : !stage.classList.contains('webfs');
  stage.classList.toggle('webfs', on);
  document.body.classList.toggle('webfs-on', on);
  paintFsButtons();
}

function paintFsButtons() {
  const fs = !!document.fullscreenElement, web = stage.classList.contains('webfs');
  document.querySelectorAll('[data-act="fs"] span').forEach((s) => (s.textContent = fs ? '退出全屏' : '全屏'));
  document.querySelectorAll('[data-act="webfs"] span').forEach((s) => (s.textContent = web ? '退出网页全屏' : '网页全屏'));
}

document.querySelectorAll('[data-act="fs"]').forEach((b) => b.addEventListener('click', toggleFullscreen));
document.querySelectorAll('[data-act="webfs"]').forEach((b) => b.addEventListener('click', () => toggleWebFullscreen()));
document.addEventListener('fullscreenchange', paintFsButtons);
video.addEventListener('dblclick', toggleFullscreen);

// 鼠标停在画面上不动 2.5 秒：藏起右上角按钮和鼠标
let idleTimer = 0;
stage.addEventListener('mousemove', () => {
  stage.classList.remove('idle');
  clearTimeout(idleTimer);
  idleTimer = setTimeout(() => stage.classList.add('idle'), 2500);
});
stage.addEventListener('mouseleave', () => { clearTimeout(idleTimer); stage.classList.remove('idle'); });

document.addEventListener('keydown', (e) => {
  if (e.target instanceof Element && e.target.matches('input, textarea, select')) return;
  if (e.key === 'd' || e.key === 'D') { on = !on; $('#on').checked = on; }
  else if (e.key === 's' || e.key === 'S') {
    settings.showSubs = !settings.showSubs;
    document.querySelector('[data-key=showSubs]').checked = settings.showSubs;
    BDA.saveSettings(settings);
  }
  else if (e.key === 'f' || e.key === 'F') toggleFullscreen();
  else if (e.key === 'w' || e.key === 'W') toggleWebFullscreen();
  else if (e.key === 'Escape' && !document.fullscreenElement && stage.classList.contains('webfs')) toggleWebFullscreen(false);
  // 按物理键位判断：中文输入法下 Shift+, / Shift+. 打出来是《》，e.key 不可靠
  else if (e.code === 'Comma' || e.key === '<' || e.key === '《') stepRate(-1);
  else if (e.code === 'Period' || e.key === '>' || e.key === '》') stepRate(1);
  else if (e.key === ' ' && e.target !== video) { e.preventDefault(); video.paused ? video.play() : video.pause(); }
  else if (e.key === 'ArrowRight' && e.target !== video) video.currentTime += 5;
  else if (e.key === 'ArrowLeft' && e.target !== video) video.currentTime -= 5;
});

// ───────────── 面板分页：弹幕 / 字幕 / 样式 ─────────────

function showPane(name) {
  document.querySelectorAll('.seg-btn').forEach((b) => b.classList.toggle('active', b.dataset.pane === name));
  document.querySelectorAll('.pane').forEach((p) => (p.hidden = p.dataset.pane !== name));
}
document.querySelectorAll('.seg-btn').forEach((b) => b.addEventListener('click', () => showPane(b.dataset.pane)));

// ───────────── 启动 ─────────────

bindControls();
showSubOffset();
fillSources().then(async () => {
  const cid = params.get('cid');
  for (const cid of params.getAll('cid')) await addCid(Number(cid));
});
requestAnimationFrame(draw);
