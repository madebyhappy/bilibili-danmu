// 在别的网站的播放器上叠加存档弹幕：YouTube，以及 B 站自己（看 B 视频时叠上 A 视频存下来的弹幕，B 站原来的弹幕照常显示）。
// 播放器右下角加一个按钮，选一个弹幕库里的存档，弹幕就画在播放器上面，跟着视频的进度走（暂停、拖动、倍速、全屏都对得上）。
//
// 每个视频记住你选了哪份弹幕、从第几秒开始，下次打开自动加载。
// 弹幕数据在插件自己的存储里，通过后台读出来，不经过这些网站。

(() => {
  if (window.__bdaOverlay) return;
  window.__bdaOverlay = true;

  // 每个网站的播放器结构不一样，在这里分别写怎么找
  const SITES = {
    youtube: {
      match: () => location.hostname === 'www.youtube.com',
      player: () => document.querySelector('#movie_player'),
      video: (p) => p.querySelector('video.html5-main-video, video'),
      layerAfter: (p) => p.querySelector('.html5-video-container'),
      controls: (p) => p.querySelector('.ytp-right-controls'),
      buttonClass: 'ytp-button',
      buttonText: '弹',
      isAd: (p) => p.classList.contains('ad-showing'),
      id() {
        const u = new URL(location.href);
        if (u.pathname === '/watch') return u.searchParams.get('v');
        const m = u.pathname.match(/^\/(?:shorts|live|embed)\/([\w-]{6,})/);
        return m ? m[1] : null;
      },
      title: () => ((document.querySelector('h1.ytd-watch-metadata, #title h1') || {}).textContent || document.title),
    },
    bilibili: {
      match: () => /(^|\.)bilibili\.com$/.test(location.hostname),
      player: () => document.querySelector('.bpx-player-container') || document.querySelector('#bilibili-player'),
      video: (p) => p.querySelector('.bpx-player-video-wrap video, .bpx-player-video-wrap bwp-video, video, bwp-video'),
      // 放在 B 站自己的弹幕层上面、控制条下面
      layerAfter: (p) => p.querySelector('.bpx-player-render-dm-wrap, .bpx-player-row-dm-wrap, .bpx-player-video-wrap'),
      controls: (p) => p.querySelector('.bpx-player-control-bottom-right'),
      buttonClass: 'bpx-player-ctrl-btn',
      buttonText: '叠',
      isAd: () => false,
      id() {
        const u = new URL(location.href);
        const p = u.searchParams.get('p') || '1';
        const bv = u.pathname.match(/\/video\/(BV[0-9A-Za-z]{10})/) || [null, u.searchParams.get('bvid')];
        if (bv[1]) return `bili:${bv[1]}:${p}`;
        const aid = u.searchParams.get('aid');
        if (aid) return `bili:av${aid}:${p}`;
        const ep = u.pathname.match(/\/bangumi\/play\/(ep\d+)/);
        return ep ? `bili:${ep[1]}` : null;
      },
      title: () => document.title.replace(/_哔哩哔哩_bilibili$/, ''),
    },
  };
  const site = Object.values(SITES).find((s) => s.match());
  if (!site) return;

  const MAP_KEY = 'bda-yt-map';         // { [视频 id]: { cid, offset } }（名字沿用最早只支持 YouTube 时的）
  const SET_KEY = 'bda-yt-settings';
  const send = (msg) => chrome.runtime.sendMessage(msg);

  let settings = Object.assign({}, BDA.DEFAULTS, { on: true });
  let videoId = null;
  let binding = null;      // { cid, offset }
  let danmaku = [];
  let items = [];
  let player = null, video = null, canvas = null, ctx = null, button = null, panel = null;
  let box = { x: 0, y: 0, w: 0, h: 0 }, dpr = 1, maxLife = 10;
  const measure = BDA.canvasMeasurer(settings.font);

  // ───────────── 存储 ─────────────

  async function loadMap() { return (await chrome.storage.local.get(MAP_KEY))[MAP_KEY] || {}; }
  async function saveBinding() {
    const map = await loadMap();
    if (binding) map[videoId] = binding; else delete map[videoId];
    await chrome.storage.local.set({ [MAP_KEY]: map });
  }
  async function loadSettings() {
    const s = (await chrome.storage.local.get(SET_KEY))[SET_KEY];
    if (s) Object.assign(settings, s);
  }
  function saveSettings() {
    const { opacity, fontSize, scrollTime, area, dropOverflow, on } = settings;
    chrome.storage.local.set({ [SET_KEY]: { opacity, fontSize, scrollTime, area, dropOverflow, on } });
  }

  // ───────────── 找播放器、挂上画布和按钮 ─────────────

  const currentVideoId = () => site.id();

  function attach() {
    const p = site.player();
    const v = p && site.video(p);
    if (!p || !v) return false;
    if (p !== player || v !== video || !canvas || !canvas.isConnected) {
      player = p;
      video = v;
      if (!canvas) {
        canvas = document.createElement('canvas');
        canvas.className = 'bda-yt-canvas';
        ctx = canvas.getContext('2d');
      }
      // 放在视频层和控制条之间：控制条、字幕都在弹幕上面，能正常点
      const after = site.layerAfter(player);
      if (after && after.parentNode) after.parentNode.insertBefore(canvas, after.nextSibling);
      else player.appendChild(canvas);
      new ResizeObserver(relayout).observe(player);
      video.addEventListener('loadedmetadata', relayout);
    }
    addButton();
    return true;
  }

  function addButton() {
    const bar = site.controls(player);
    if (!bar || (button && button.isConnected)) return;
    button = document.createElement('button');
    button.className = `${site.buttonClass} bda-yt-btn`;
    button.title = '叠加存档弹幕（Bilibili 弹幕存档）';
    button.setAttribute('aria-label', '叠加存档弹幕');
    const label = document.createElement('span');
    label.textContent = site.buttonText;
    button.append(label);
    button.addEventListener('click', (e) => { e.stopPropagation(); togglePanel(); });
    bar.prepend(button);
    paintButton();
  }

  function paintButton() {
    if (!button) return;
    button.classList.toggle('bda-on', !!(binding && settings.on));
    button.classList.toggle('bda-bound', !!binding);
  }

  // ───────────── 切视频（YouTube 是单页应用，不会刷新页面） ─────────────

  async function onNavigate() {
    const id = currentVideoId();
    if (!attach()) return;
    if (id === videoId) return;
    videoId = id;
    binding = id ? (await loadMap())[id] || null : null;
    danmaku = [];
    items = [];
    if (binding) await loadDanmaku();
    paintButton();
    if (panel && panel.host.isConnected && !panel.host.hidden) renderPanel();
  }

  async function loadDanmaku() {
    const r = await send({ type: 'dm-get', cid: binding.cid });
    if (!r || !r.ok) {
      danmaku = [];
      binding.missing = true;
    } else {
      danmaku = r.list;
      binding.missing = false;
    }
    relayout();
  }

  // ───────────── 排版 + 绘制（和插件自带播放器一样的算法） ─────────────

  function relayout() {
    if (!player || !video || !canvas) return;
    const pr = (canvas.parentElement || player).getBoundingClientRect();
    const vr = video.getBoundingClientRect();
    dpr = window.devicePixelRatio || 1;
    canvas.width = Math.round(pr.width * dpr);
    canvas.height = Math.round(pr.height * dpr);
    canvas.style.width = pr.width + 'px';
    canvas.style.height = pr.height + 'px';
    // 视频元素本身可能比画面大（object-fit: contain 的黑边），按画面比例再算一次
    const vw = video.videoWidth || 16, vh = video.videoHeight || 9;
    const s = Math.min(vr.width / vw, vr.height / vh) || 0;
    box = {
      w: vw * s, h: vh * s,
      x: vr.left - pr.left + (vr.width - vw * s) / 2,
      y: vr.top - pr.top + (vr.height - vh * s) / 2,
    };
    const opts = Object.assign({}, settings, { offset: binding ? binding.offset || 0 : 0 });
    items = danmaku.length && box.h > 0 ? BDA.layout(danmaku, box.w, box.h, opts, measure) : [];
    maxLife = Math.max(settings.scrollTime, settings.fixTime);
  }

  function lowerBound(x) {
    let lo = 0, hi = items.length;
    while (lo < hi) { const mid = (lo + hi) >> 1; if (items[mid].t < x) lo = mid + 1; else hi = mid; }
    return lo;
  }

  function draw() {
    requestAnimationFrame(draw);
    if (!ctx) return;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    // 广告时不显示
    if (!settings.on || !items.length || !video || site.isAd(player)) return;
    const now = video.currentTime;
    ctx.setTransform(dpr, 0, 0, dpr, box.x * dpr, box.y * dpr);
    ctx.globalAlpha = settings.opacity;
    ctx.textBaseline = 'top';
    ctx.lineJoin = 'round';
    ctx.lineWidth = Math.max(2, box.h / 400);
    let lastFont = '';
    for (let i = lowerBound(now - maxLife); i < items.length; i++) {
      const it = items[i];
      if (it.t > now) break;
      if (now >= it.end) continue;
      const x = it.kind === 'scroll' ? box.w - (now - it.t) * it.v : (box.w - it.w) / 2;
      const font = `${it.size}px "${settings.font}", "PingFang SC", "Microsoft YaHei", sans-serif`;
      if (font !== lastFont) { ctx.font = font; lastFont = font; }
      const c = it.dm.c & 0xffffff;
      const r = c >> 16, g = (c >> 8) & 0xff, b = c & 0xff;
      ctx.strokeStyle = 0.299 * r + 0.587 * g + 0.114 * b < 60 ? 'rgba(255,255,255,.9)' : 'rgba(0,0,0,.75)';
      ctx.fillStyle = '#' + c.toString(16).padStart(6, '0');
      ctx.strokeText(it.text, x, it.y);
      ctx.fillText(it.text, x, it.y);
    }
  }

  // ───────────── 面板（放在 shadow DOM 里，不受 YouTube 样式影响） ─────────────

  function el(tag, props, ...children) {
    const n = document.createElement(tag);
    for (const [k, v] of Object.entries(props || {})) {
      if (v == null) continue;
      if (k === 'class') n.className = v;
      else if (k.startsWith('on')) n.addEventListener(k.slice(2), v);
      else if (k in n) n[k] = v;
      else n.setAttribute(k, v);
    }
    for (const c of children.flat()) if (c != null && c !== false) n.append(c instanceof Node ? c : String(c));
    return n;
  }

  function ensurePanel() {
    if (panel && panel.host.isConnected) return panel;
    const host = el('div', { class: 'bda-yt-panel-host' });
    host.hidden = true;
    const root = host.attachShadow({ mode: 'open' });
    const style = el('style');
    style.textContent = PANEL_CSS;
    const body = el('div', { class: 'panel' });
    root.append(style, body);
    // 面板里的点击、按键不要传给 YouTube（不然会暂停 / 触发快捷键）
    for (const ev of ['click', 'mousedown', 'keydown', 'keyup', 'keypress', 'wheel', 'dblclick']) {
      host.addEventListener(ev, (e) => e.stopPropagation());
    }
    player.appendChild(host);
    panel = { host, body };
    return panel;
  }

  async function togglePanel() {
    const p = ensurePanel();
    p.host.hidden = !p.host.hidden;
    if (p.host.hidden) return;
    // 打开面板时重新读一次，弹幕库里刚更新过的也能拿到
    if (binding) await loadDanmaku();
    await renderPanel();
  }

  document.addEventListener('click', (e) => {
    if (panel && !panel.host.hidden && !panel.host.contains(e.target) && e.target !== button && !(button && button.contains(e.target))) {
      panel.host.hidden = true;
    }
  }, true);

  // 和弹幕库标题有多少字重合，用来猜“可能是这一个”
  function similarity(a, b) {
    const grams = (s) => {
      const t = s.toLowerCase().replace(/[\s【】\[\]()（）《》「」|_\-·:：,，.。!！?？"'“”]+/g, '');
      const set = new Set();
      for (let i = 0; i < t.length - 1; i++) set.add(t.slice(i, i + 2));
      return set;
    };
    const A = grams(a), B = grams(b);
    let n = 0;
    for (const g of A) if (B.has(g)) n++;
    return n / Math.max(1, Math.min(A.size, B.size));
  }

  async function renderPanel() {
    const { body } = ensurePanel();
    const r = await send({ type: 'dm-list' });
    const videos = (r && r.videos) || [];
    const ytTitle = site.title();
    const labelOf = (v) => v.kind === 'merged' ? `合并版 · ${v.groupTitle}`
      : v.partsTotal > 1 ? `${v.groupTitle} · P${v.page} ${v.part}` : (v.kind === 'import' ? v.part : v.groupTitle);

    // 按标题猜“可能是”哪一份
    const guesses = videos
      .map((v) => ({ v, s: similarity(ytTitle, labelOf(v)) }))
      .filter((x) => x.s >= 0.25).sort((a, b) => b.s - a.s).slice(0, 3).map((x) => x.v.cid);
    const choose = async (cid) => {
      binding = cid ? { cid, offset: binding && binding.cid === cid ? binding.offset : 0 } : null;
      await saveBinding();
      if (binding) await loadDanmaku(); else { danmaku = []; items = []; }
      paintButton();
      renderPanel();
    };
    const picker = BDA.renderArchivePicker({ videos, selected: binding ? binding.cid : null, guesses, onPick: choose, placeholder: '搜弹幕库…', dropdown: true });
    const clear = binding ? el('button', { class: 'small', onclick: () => choose(0) }, '不显示') : null;

    const status = binding
      ? (binding.missing ? '这份存档在弹幕库里找不到了（可能删了）' : `已加载 ${danmaku.length.toLocaleString('zh-CN')} 条弹幕`)
      : (videos.length ? '这个视频还没选弹幕' : '弹幕库是空的。先去 B 站存一些弹幕吧。');

    const on = el('input', { type: 'checkbox', checked: settings.on, onchange: () => { settings.on = on.checked; saveSettings(); paintButton(); } });

    const startInput = el('input', { type: 'text', class: 'num', value: fmtClock(binding ? binding.offset || 0 : 0),
      title: '分:秒。↑↓ 键每次 0.5 秒，按住 Shift 每次 5 秒' });
    const setOffset = async (sec) => {
      if (!binding) return;
      binding.offset = Math.round(sec * 10) / 10;
      startInput.value = fmtClock(binding.offset);
      await saveBinding();
      relayout();
    };
    startInput.addEventListener('change', () => { const v = parseClock(startInput.value); if (v != null) setOffset(v); else startInput.value = fmtClock(binding ? binding.offset : 0); });
    const stepper = stepperEl(startInput, () => (binding ? binding.offset || 0 : 0), setOffset);

    const slider = (key, label, min, max, step, fmt) => {
      const out = el('span', { class: 'val' }, fmt(settings[key]));
      const input = el('input', { type: 'range', min, max, step, value: settings[key] });
      input.addEventListener('input', () => {
        settings[key] = Number(input.value);
        out.textContent = fmt(settings[key]);
        saveSettings();
        relayoutSoon();
      });
      return el('label', { class: 'slider' }, el('span', {}, label), out, input);
    };

    body.replaceChildren(
      el('div', { class: 'head' }, el('strong', {}, 'Bilibili 弹幕存档'),
        el('button', { class: 'link', onclick: () => send({ type: 'open-page', path: 'library.html' }) }, '弹幕库 ↗')),
      el('div', { class: 'status-row' }, el('div', { class: 'status' }, status), clear),
      picker,
      el('label', { class: 'check' }, on, '显示弹幕'),
      binding ? el('div', { class: 'row' }, '视频的', stepper, el('button', { class: 'small', onclick: () => setOffset(video ? video.currentTime : 0) }, '从这里开始')) : null,
      binding ? el('div', { class: 'hint' }, site === SITES.bilibili
        ? '弹幕从视频的这个时间开始出现。两个版本的片头不一样长时调这个。B 站这个视频自己的弹幕照常显示。'
        : '弹幕从视频的这个时间开始出现。YouTube 版本开头多了片头或广告口播时调这个。') : null,
      slider('opacity', '不透明度', 0.1, 1, 0.05, (v) => Math.round(v * 100) + '%'),
      slider('fontSize', '字号', 20, 80, 1, (v) => v + ' px'),
      slider('scrollTime', '滚动时长', 4, 20, 0.5, (v) => v + ' 秒'),
      slider('area', '显示区域', 0.1, 1, 0.05, (v) => (v >= 1 ? '全屏' : `上 ${Math.round(v * 100)}%`)),
    );
  }

  function stepperEl(input, get, set) {
    const bump = (dir, big) => set(get() + dir * (big ? 5 : 0.5));
    const mk = (dir, txt) => {
      const b = el('button', { type: 'button', class: 'arrow', title: dir > 0 ? '晚 0.5 秒' : '早 0.5 秒' }, txt);
      let timer = 0, repeat = 0;
      const stop = () => { clearTimeout(timer); clearInterval(repeat); };
      b.addEventListener('pointerdown', (e) => {
        e.preventDefault();
        bump(dir, e.shiftKey);
        const big = e.shiftKey;
        timer = setTimeout(() => { repeat = setInterval(() => bump(dir, big), 80); }, 400);
      });
      b.addEventListener('pointerup', stop);
      b.addEventListener('pointerleave', stop);
      return b;
    };
    input.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowUp' || e.key === 'ArrowDown') { e.preventDefault(); bump(e.key === 'ArrowUp' ? 1 : -1, e.shiftKey); }
    });
    return el('span', { class: 'stepper' }, input, el('span', { class: 'arrows' }, mk(1, '▲'), mk(-1, '▼')));
  }

  function fmtClock(sec) {
    const neg = sec < 0;
    sec = Math.abs(Math.round(sec * 10) / 10);
    const h = Math.floor(sec / 3600), m = Math.floor(sec / 60) % 60, s = sec % 60;
    const ss = (s < 10 ? '0' : '') + (Number.isInteger(s) ? s : s.toFixed(1));
    return (neg ? '-' : '') + (h ? `${h}:${String(m).padStart(2, '0')}:${ss}` : `${m}:${ss}`);
  }

  function parseClock(text) {
    const t = text.trim().replace(/：/g, ':');
    const neg = t.startsWith('-');
    const parts = t.replace(/^-/, '').split(':').map(Number);
    if (!parts.length || parts.some((n) => !isFinite(n))) return null;
    const sec = parts.reduce((acc, n) => acc * 60 + n, 0);
    return neg ? -sec : sec;
  }

  let relayoutTimer = 0;
  function relayoutSoon() { clearTimeout(relayoutTimer); relayoutTimer = setTimeout(relayout, 120); }

  const PANEL_CSS = BDA.archivePickerCSS + `
    :host { all: initial; --pk-line: #3a3a40; --pk-bg: #222226; --pk-hover: #2e2e34; --pk-muted: #9a9aa4; --pk-accent: #ff86aa; }
    .status-row { display: flex; align-items: center; justify-content: space-between; gap: 8px; }
    .panel {
      position: absolute; right: 12px; bottom: 64px; z-index: 80;
      width: 330px; max-height: calc(100% - 90px); overflow: auto; box-sizing: border-box;
      padding: 12px 14px; border-radius: 10px;
      background: rgba(28, 28, 30, .94); color: #eee;
      font: 13px/1.5 -apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif;
      box-shadow: 0 8px 30px rgba(0,0,0,.45);
      display: flex; flex-direction: column; gap: 8px;
    }
    .head { display: flex; align-items: center; justify-content: space-between; }
    .head strong { color: #ff85a8; }
    input, select, button { font: inherit; color: inherit; }
    input[type=text], select { width: 100%; box-sizing: border-box; background: #2c2c30; border: 1px solid #3a3a40; border-radius: 6px; padding: 5px 8px; }
    select optgroup { color: #999; }
    select option { color: #eee; }
    button { background: #2c2c30; border: 1px solid #3a3a40; border-radius: 6px; padding: 3px 9px; cursor: pointer; }
    button:hover { border-color: #ff85a8; color: #ff85a8; }
    button.link { background: none; border: 0; color: #9ad; padding: 0; }
    .status { color: #aaa; font-size: 12px; }
    .hint { color: #888; font-size: 11px; margin-top: -4px; }
    .check { display: flex; align-items: center; gap: 6px; cursor: pointer; }
    .check input { accent-color: #fb7299; }
    .row { display: flex; align-items: center; gap: 6px; }
    .stepper { display: inline-flex; align-items: stretch; }
    .stepper input.num { width: 72px; text-align: center; border-radius: 6px 0 0 6px; font-variant-numeric: tabular-nums; }
    .arrows { display: flex; flex-direction: column; border: 1px solid #3a3a40; border-left: 0; border-radius: 0 6px 6px 0; overflow: hidden; }
    .arrow { flex: 1; border: 0; border-radius: 0; padding: 0 7px; font-size: 8px; line-height: 1; color: #aaa; }
    .arrow + .arrow { border-top: 1px solid #3a3a40; }
    .slider { display: grid; grid-template-columns: 1fr auto; }
    .slider input { grid-column: 1 / -1; width: 100%; accent-color: #fb7299; }
    .slider .val { color: #aaa; font-variant-numeric: tabular-nums; }
  `;

  // ───────────── 启动 ─────────────

  (async function init() {
    await loadSettings();
    requestAnimationFrame(draw);
    onNavigate();
    // YouTube 换视频不刷新页面；B 站切分P也不刷新
    window.addEventListener('yt-navigate-finish', onNavigate);
    // 播放器有时比事件晚出来、切视频也不一定有事件，兜底每秒检查一次
    setInterval(onNavigate, 1000);
  })();
})();
