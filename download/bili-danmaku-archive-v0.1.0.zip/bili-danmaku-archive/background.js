// 后台：管理跑存档任务的 offscreen 页面、更新工具栏角标、给插件自己的请求加 B 站请求头；
// 给 YouTube 页面上的弹幕层读弹幕库（网页里的脚本读不到插件自己的存储，要经过这里）。

importScripts('lib/db.js');

const OFFSCREEN = 'offscreen.html';
let creating = null;

async function ensureRunner() {
  const existing = await chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'] });
  if (existing.length) return;
  if (!creating) {
    creating = chrome.offscreen.createDocument({
      url: OFFSCREEN,
      reasons: ['DOM_PARSER'],
      justification: '在后台拉取并解析弹幕，弹窗关掉也不中断',
    }).finally(() => { creating = null; });
  }
  await creating;
}

async function enqueue(tasks, merge) {
  await ensureRunner();
  // offscreen 页面刚建好时脚本可能还没跑完，多试几次
  for (let i = 0; i < 20; i++) {
    try {
      const r = await chrome.runtime.sendMessage({ type: 'runner-enqueue', tasks, merge });
      if (r && r.ok) return;
    } catch { /* 还没准备好 */ }
    await new Promise((res) => setTimeout(res, 100));
  }
  throw new Error('后台任务没有启动起来');
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'job-start') {
    enqueue(msg.tasks, msg.merge).then(() => sendResponse({ ok: true }), (e) => sendResponse({ ok: false, error: e.message }));
    return true;
  }
  if (msg.type === 'dm-list') {
    BDA.db.listVideos().then((videos) => sendResponse({
      ok: true,
      videos: videos.map(({ cid, groupKey, groupTitle, part, page, partsTotal, kind, count, duration, lastUpdated, sources }) =>
        ({ cid, groupKey, groupTitle, part, page, partsTotal, kind, count, duration, lastUpdated,
          sources: sources ? sources.map((x) => ({ cid: x.cid })) : undefined })),
    }), (e) => sendResponse({ ok: false, error: e.message }));
    return true;
  }
  if (msg.type === 'dm-get') {
    Promise.all([BDA.db.getVideo(msg.cid), BDA.db.getDanmaku(msg.cid)]).then(([meta, list]) =>
      sendResponse(meta ? { ok: true, list } : { ok: false }), (e) => sendResponse({ ok: false, error: e.message }));
    return true;
  }
  if (msg.type === 'open-page') {
    chrome.tabs.create({ url: chrome.runtime.getURL(msg.path) });
    return false;
  }
  if (msg.type === 'job-state') updateBadge(msg.state);
  if (msg.type === 'badge-clear') chrome.action.setBadgeText({ text: '' });
  return false;
});

function updateBadge(state) {
  if (state.running) {
    chrome.action.setBadgeBackgroundColor({ color: '#fb7299' });
    chrome.action.setBadgeText({ text: '…' });
  } else if (state.finishedAt) {
    chrome.action.setBadgeBackgroundColor({ color: '#16a34a' });
    chrome.action.setBadgeText({ text: '✓' });
  }
}

// 插件自己发出的 B 站接口请求带上 B 站的 Referer/Origin，不然容易被风控拦（412）。
// 只作用于本插件发起的请求，不影响你正常浏览 B 站。
async function installHeaderRule() {
  await chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: [1],
    addRules: [{
      id: 1,
      priority: 1,
      action: {
        type: 'modifyHeaders',
        requestHeaders: [
          { header: 'referer', operation: 'set', value: 'https://www.bilibili.com/' },
          { header: 'origin', operation: 'set', value: 'https://www.bilibili.com' },
        ],
      },
      condition: {
        requestDomains: ['bilibili.com'],
        initiatorDomains: [chrome.runtime.id],
        resourceTypes: ['xmlhttprequest'],
      },
    }],
  });
}

chrome.runtime.onInstalled.addListener(installHeaderRule);
chrome.runtime.onStartup.addListener(installHeaderRule);
