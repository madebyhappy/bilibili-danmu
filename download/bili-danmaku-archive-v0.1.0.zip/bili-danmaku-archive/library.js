// 弹幕库页面：所有存档、更新、导出、导入/备份；也能粘贴链接直接存。
// 存档任务交给后台跑（和弹窗共用一个队列），这里只负责显示进度。

const { db, h, fmtNum, fmtTime } = BDA;
const $ = (s) => document.querySelector(s);
const params = new URLSearchParams(location.search);
let shown = null;

// ───────────── 登录状态 ─────────────

async function checkLogin() {
  const login = await BDA.getLogin();
  const pill = $('#login');
  if (login.isLogin) {
    pill.className = 'pill ok';
    pill.textContent = `已登录 B 站：${login.uname}`;
    pill.title = '可以下载完整弹幕';
  } else {
    pill.className = 'pill warn';
    pill.textContent = '未登录 B 站';
    pill.title = '能存现在的弹幕；下载完整弹幕需要先在这个浏览器里登录 B 站';
  }
}

// ───────────── 粘贴链接存档 ─────────────

async function show(text) {
  const box = $('#current');
  box.replaceChildren(h('div', { class: 'muted', style: 'margin-top:12px' }, '正在读取视频信息…'));
  const res = await BDA.lookup(text);
  if (!res.video) {
    const saved = res.gone && res.key ? (await db.listVideos()).some((v) => v.groupKey === res.key) : false;
    box.replaceChildren(h('div', { class: 'lookup-err' }, res.error,
      saved ? ' 不过你的弹幕库里有它的存档，已经在下面筛出来了。' : ''));
    if (saved) { $('#search').value = res.key; renderLibrary(); }
    return;
  }
  shown = { video: res.video, opts: res.opts, warnings: res.warnings };
  await renderShown();
}

async function renderShown() {
  if (!shown) return;
  const saved = new Map((await db.listVideos()).map((v) => [v.cid, v]));
  $('#current').replaceChildren(
    shown.warnings && shown.warnings.length ? h('div', { class: 'lookup-err' }, `有 ${shown.warnings.length} 个链接没查到：${shown.warnings.join('；')}`) : '',
    BDA.renderPicker(shown.video, saved, Object.assign({ onStart: startJob }, shown.opts)));
}

$('#lookupForm').addEventListener('submit', (e) => {
  e.preventDefault();
  const v = $('#lookupInput').value.trim();
  if (v) show(v);
});
BDA.autoGrowInput($('#lookupInput'), $('#lookupForm'));

// ───────────── 后台任务 ─────────────

async function startJob(tasks, merge) {
  const r = await BDA.jobs.start(tasks, merge);
  if (r && !r.ok) alert(r.error);
}

let lastVersion = -1, lastLogLen = 0;
function onJobState(state) {
  if (!state || state.version <= lastVersion) return;
  lastVersion = state.version;
  const box = $('#job');
  if (!state.running && !state.finishedAt) { box.hidden = true; return; }
  box.hidden = false;
  box.classList.toggle('running', state.running);
  box.replaceChildren(...BDA.renderJob(state));
  const log = box.querySelector('.job-log');
  if (log) log.scrollTop = log.scrollHeight;
  if (state.log.length !== lastLogLen || !state.running) {
    lastLogLen = state.log.length;
    renderLibrary();
    refreshShown();
  }
}
BDA.jobs.onState(onJobState);

async function refreshShown() {
  const picker = $('#current .picker');
  if (picker && picker.refreshSaved) picker.refreshSaved(new Map((await db.listVideos()).map((v) => [v.cid, v])));
}

function taskFor(v) {
  const { cid, groupKey, groupTitle, kind, bvid, epId, page, part, duration, pubTs, partsTotal, danmakuTotal } = v;
  // 弹幕超过 1 万条（或者以前已经下过完整弹幕）的才带上「下载完整弹幕」
  const big = (danmakuTotal || 0) > BDA.FULL_DANMAKU_OVER || (v.historyDates || []).length > 0;
  return { meta: { cid, groupKey, groupTitle, kind, bvid, epId, page, part, duration, pubTs, partsTotal, danmakuTotal }, history: BDA.historyPref.get() && big };
}

// ───────────── 弹幕库列表 ─────────────

async function renderLibrary() {
  const videos = await db.listVideos();
  libIndex = new Map(videos.map((v) => [v.cid, v]));
  const q = $('#search').value.trim().toLowerCase();
  const groups = new Map();
  for (const v of videos) {
    if (q && !(`${v.groupTitle} ${v.part} ${v.groupKey}`.toLowerCase().includes(q))) continue;
    if (!groups.has(v.groupKey)) groups.set(v.groupKey, []);
    groups.get(v.groupKey).push(v);
  }
  const sorted = [...groups.values()]
    .map((parts) => parts.sort((a, b) => a.page - b.page))
    .sort((a, b) => Math.max(...b.map((p) => p.lastUpdated)) - Math.max(...a.map((p) => p.lastUpdated)));

  const real = videos.filter((v) => v.kind !== 'merged');
  const total = real.reduce((s, v) => s + v.count, 0);
  const groupCount = new Set(real.map((v) => v.groupKey)).size;
  const mergedCount = videos.length - real.length;
  const stat = (n, label) => h('span', {}, h('b', {}, fmtNum(n)), label);
  $('#libStats').replaceChildren(...(videos.length ? [
    stat(groupCount, '个视频'), stat(real.length, '个分P'), stat(total, '条弹幕'),
    mergedCount ? stat(mergedCount, '个合并版') : null,
  ].filter(Boolean) : []));
  $('#empty').hidden = videos.length > 0;
  $('#library').replaceChildren(...sorted.map(renderGroup));
}

let libIndex = new Map();

// 分P多的视频默认收起，只显示一行标题；点标题行或箭头展开。展开状态记在本地。
const COLLAPSE_OVER = 3;
const expanded = new Set((() => { try { return JSON.parse(localStorage.getItem('bda-expanded') || '[]'); } catch { return []; } })());
function setExpanded(key, on) {
  if (on) expanded.add(key); else expanded.delete(key);
  try { localStorage.setItem('bda-expanded', JSON.stringify([...expanded])); } catch { /* 记不住就算了 */ }
}

function renderGroup(parts) {
  const first = parts[0];
  if (first.kind === 'merged') return renderMerged(first);
  const updatable = first.kind !== 'import';
  const link = BDA.videoLink(first.groupKey, first.kind);
  const total = parts.reduce((s, p) => s + p.count, 0);
  const lastUpdated = Math.max(...parts.map((p) => p.lastUpdated || 0));
  const collapsible = parts.length > COLLAPSE_OVER;
  // 搜索时直接展开，方便看到匹配的分P
  const open = !collapsible || expanded.has(first.groupKey) || !!$('#search').value.trim();
  const card = h('div', { class: 'card group' + (collapsible ? ' collapsible' : '') + (open ? ' open' : '') });
  const toggle = () => {
    const now = !card.classList.contains('open');
    card.classList.toggle('open', now);
    setExpanded(first.groupKey, now);
  };
  const head = h('div', { class: 'group-head', onclick: collapsible ? (e) => { if (!e.target.closest('a, button')) toggle(); } : null },
    collapsible ? h('button', { class: 'chev ghost small icon-btn', title: '展开 / 收起', onclick: toggle },
      svg('<path d="M9 6l6 6-6 6"/>')) : null,
    h('div', { class: 'title' },
      link ? h('a', { href: link, target: '_blank' }, first.groupTitle) : first.groupTitle,
      collapsible ? h('div', { class: 'sub muted' }, `更新于 ${fmtTime(lastUpdated)}`) : null),
    h('span', { class: 'meta muted' }, `${parts.length > 1 ? parts.length + ' 个分P · ' : ''}${fmtNum(total)} 条`),
    updatable && parts.length > 1 ? h('button', { class: 'small', onclick: () => startJob(parts.map(taskFor)) }, '全部更新') : null,
    parts.length > 1 ? h('button', { class: 'small', onclick: () => exportGroup(parts) }, '全部导出 ASS') : null);
  card.append(head,
    h('div', { class: 'group-body' },
      h('table', { class: 'parts-table' }, h('tbody', {}, parts.map((p) => renderPart(p, parts.length > 1, updatable))))));
  return card;
}

// 小图标：直接写 SVG 路径
function svg(paths) {
  const el = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  el.setAttribute('viewBox', '0 0 24 24');
  el.innerHTML = paths;
  return el;
}

function renderPart(v, multi, updatable) {
  const last = [...(v.log || [])].reverse().find((l) => l.added != null);
  const histDays = (v.historyDates || []).length;
  return h('tr', {},
    h('td', { class: 'name' },
      h('div', {}, multi ? `P${v.page} · ${v.part}` : (v.kind === 'import' ? v.part : '整个视频')),
      h('div', { class: 'last muted' },
        `更新于 ${fmtTime(v.lastUpdated)}`,
        histDays ? ' · 已下载完整弹幕' : '',
        v.log && v.log.length > 1 ? ` · 共存档 ${v.log.filter((l) => l.note === '当前弹幕池').length} 次` : '')),
    h('td', { class: 'num' }, fmtNum(v.count),
      last ? h('span', { class: 'delta' + (last.added ? '' : ' muted') }, last.added ? `上次 +${fmtNum(last.added)}` : '上次无新增') : null),
    h('td', { class: 'acts' },
      updatable ? h('button', { class: 'small', onclick: () => startJob([taskFor(v)]) }, '更新') : null,
      h('button', { class: 'small', onclick: () => exportOne(v, 'ass') }, 'ASS'),
      h('button', { class: 'small', onclick: () => exportOne(v, 'xml') }, 'XML'),
      h('button', { class: 'small', onclick: () => window.open(`player.html?cid=${v.cid}`) }, '播放'),
      h('button', { class: 'small danger', onclick: () => removeOne(v) }, '删除')));
}

// 合并版：一行显示由哪几段拼成；“更新”= 更新所有源分P，存完后台会自动重新合并
function renderMerged(v) {
  const srcMetas = v.sources.map((s) => libIndex.get(s.cid)).filter(Boolean);
  const missing = v.sources.length - srcMetas.length;
  const last = [...(v.log || [])].reverse()[0];
  return h('div', { class: 'card group' },
    h('div', { class: 'group-head' },
      h('div', { class: 'title' }, h('span', { class: 'merged-tag' }, '合并版'), v.groupTitle),
      h('span', { class: 'meta muted' }, `${v.sources.length} 段 · ${BDA.fmtDuration(v.duration)} · ${fmtNum(v.count)} 条`)),
    h('table', { class: 'parts-table' }, h('tbody', {}, h('tr', {},
      h('td', { class: 'name' },
        h('div', { class: 'sources', title: v.sources.map((s, i) => `${i + 1}. ${s.label}`).join('\n') },
          v.sources.map((s) => s.label).join(' → ')),
        h('div', { class: 'last muted' },
          `合并于 ${fmtTime(v.lastUpdated)}`,
          missing ? ` · ${missing} 段的存档已经删了` : '',
          last && last.note !== '合并' ? ` · ${last.note}` : '')),
      h('td', { class: 'num' }, fmtNum(v.count)),
      h('td', { class: 'acts' },
        h('button', { class: 'small', title: '更新每一段的弹幕，然后重新合并', disabled: !srcMetas.length,
          onclick: () => startJob(srcMetas.filter((m) => m.kind !== 'import').map(taskFor)) }, '更新'),
        h('button', { class: 'small', onclick: () => openMergeDialog(v) }, '编辑'),
        h('button', { class: 'small', onclick: () => exportOne(v, 'ass') }, 'ASS'),
        h('button', { class: 'small', onclick: () => exportOne(v, 'xml') }, 'XML'),
        h('button', { class: 'small', onclick: () => window.open(`player.html?cid=${v.cid}`) }, '播放'),
        h('button', { class: 'small danger', onclick: () => removeOne(v) }, '删除'))))));
}

$('#search').addEventListener('input', () => renderLibrary());

// ───────────── 合并编辑 ─────────────

const labelOf = (v) => (v.partsTotal > 1 ? `${v.groupTitle} · P${v.page} ${v.part}` : (v.kind === 'import' ? v.part : v.groupTitle));
let mergeEditing = null;   // 正在编辑的合并版（新建时为 null）
let mergeRows = [];        // [{ cid, label, duration }]

function parseDur(text) {
  const parts = String(text).trim().replace(/：/g, ':').split(':').map(Number);
  if (!parts.length || parts.some((n) => !isFinite(n) || n < 0)) return null;
  return parts.reduce((acc, n) => acc * 60 + n, 0);
}
function fmtDur(sec) {
  const whole = Math.floor(sec), frac = Math.round((sec - whole) * 10);
  return BDA.fmtDuration(whole) + (frac ? `.${frac}` : '');
}

function openMergeDialog(existing) {
  mergeEditing = existing || null;
  mergeRows = existing ? existing.sources.map((s) => Object.assign({}, s)) : [];
  $('#mergeHeading').textContent = existing ? '编辑合并' : '合并成一条完整弹幕';
  $('#mergeSave').textContent = existing ? '保存并重新合并' : '合并';
  $('#mergeName').value = existing ? existing.groupTitle : '';
  const sel = $('#mergeAddSel');
  sel.replaceChildren();
  const groups = new Map();
  for (const v of [...libIndex.values()].filter((x) => x.kind !== 'merged').sort((a, b) =>
    a.groupTitle.localeCompare(b.groupTitle, 'zh-CN') || a.page - b.page)) {
    if (!groups.has(v.groupKey)) {
      const g = document.createElement('optgroup');
      g.label = v.groupTitle;
      groups.set(v.groupKey, g);
      sel.append(g);
    }
    groups.get(v.groupKey).append(new Option(`${v.partsTotal > 1 ? `P${v.page} ${v.part}` : '整个视频'}（${BDA.fmtDuration(v.duration)}）`, v.cid));
  }
  renderMergeRows();
  $('#mergeDialog').showModal();
}

function addMergeRow(v) {
  mergeRows.push({ cid: v.cid, label: labelOf(v), duration: v.duration || 0 });
  if (!$('#mergeName').value) $('#mergeName').value = v.groupTitle;
}

function renderMergeRows() {
  let start = 0;
  $('#mergeRows').replaceChildren(...mergeRows.map((r, i) => {
    const at = start;
    start += r.duration;
    const dur = h('input', { type: 'text', value: fmtDur(r.duration), title: '这一段的时长（分:秒）',
      onchange: () => { const d = parseDur(dur.value); if (d != null) r.duration = d; renderMergeRows(); } });
    const move = (to) => { const [x] = mergeRows.splice(i, 1); mergeRows.splice(to, 0, x); renderMergeRows(); };
    return h('li', {},
      h('span', { class: 'idx' }, i + 1),
      h('span', { class: 'lbl', title: r.label }, r.label),
      dur,
      h('span', { class: 'start', title: '在合并后的视频里从这里开始' }, `从 ${fmtDur(at)}`),
      h('span', { class: 'btns' },
        h('button', { class: 'small', disabled: i === 0, onclick: () => move(i - 1), title: '上移' }, '↑'),
        h('button', { class: 'small', disabled: i === mergeRows.length - 1, onclick: () => move(i + 1), title: '下移' }, '↓'),
        h('button', { class: 'small danger', onclick: () => { mergeRows.splice(i, 1); renderMergeRows(); }, title: '去掉' }, '✕')));
  }));
  $('#mergeTotal').textContent = mergeRows.length ? `${mergeRows.length} 段，合起来 ${fmtDur(start)}` : '';
  $('#mergeSave').disabled = mergeRows.length < 2;
}

$('#newMerge').addEventListener('click', () => openMergeDialog(null));
$('#mergeCancel').addEventListener('click', () => $('#mergeDialog').close());
$('#mergeAddOne').addEventListener('click', () => {
  const v = libIndex.get(Number($('#mergeAddSel').value));
  if (v) { addMergeRow(v); renderMergeRows(); }
});
$('#mergeAddGroup').addEventListener('click', () => {
  const v = libIndex.get(Number($('#mergeAddSel').value));
  if (!v) return;
  [...libIndex.values()].filter((x) => x.groupKey === v.groupKey && x.kind !== 'merged')
    .sort((a, b) => a.page - b.page).forEach(addMergeRow);
  renderMergeRows();
});
$('#mergeSave').addEventListener('click', async () => {
  const title = $('#mergeName').value.trim() || mergeRows[0].label;
  const r = await BDA.buildMerged({ cid: mergeEditing && mergeEditing.cid, title, sources: mergeRows });
  $('#mergeDialog').close();
  await renderLibrary();
  if (r.missing.length) alert(`有 ${r.missing.length} 段没有存档，合并时跳过了：${r.missing.join('、')}`);
});

// ───────────── 导出 / 导入 / 备份 ─────────────

function fileBase(v) {
  if (v.kind === 'import' || v.kind === 'merged') return BDA.safeName(v.part);
  return BDA.safeName(v.partsTotal > 1 ? `${v.groupTitle} - P${v.page} ${v.part}` : v.groupTitle);
}

async function exportOne(v, kind) {
  const list = await db.getDanmaku(v.cid);
  if (kind === 'xml') BDA.download(fileBase(v) + '.xml', BDA.toXML(v.cid, list), 'text/xml;charset=utf-8');
  else BDA.download(fileBase(v) + '.ass', BDA.toASS(v.groupTitle, list, BDA.loadSettings()));
}

async function exportGroup(parts) {
  for (const p of parts) {
    await exportOne(p, 'ass');
    await new Promise((r) => setTimeout(r, 300)); // 连续下载太快会被浏览器拦
  }
}

async function removeOne(v) {
  if (!confirm(`删除「${v.partsTotal > 1 ? v.part : v.groupTitle}」的 ${fmtNum(v.count)} 条存档弹幕？删除后不能恢复（除非你有备份）。`)) return;
  await db.remove(v.cid);
  renderLibrary();
  refreshShown();
}

$('#backupBtn').addEventListener('click', async () => {
  const videos = await db.listVideos();
  if (!videos.length) return alert('弹幕库是空的。');
  const entries = [];
  for (const meta of videos) entries.push({ meta, list: await db.getDanmaku(meta.cid) });
  BDA.download(`弹幕库备份-${BDA.ymd(new Date())}.json`, BDA.toBackup(entries), 'application/json');
});

$('#importBtn').addEventListener('click', () => $('#importFile').click());
$('#importFile').addEventListener('change', async (e) => {
  const files = [...e.target.files];
  e.target.value = '';
  const results = [];
  for (const f of files) {
    try {
      const text = await BDA.readText(f); // 自动识别 UTF-8 / GBK
      if (/\.json$/i.test(f.name)) {
        let added = 0;
        const entries = BDA.parseBackup(text);
        for (const { meta, list } of entries) added += (await db.merge(meta, list, '导入备份')).added;
        results.push(`${f.name}：${entries.length} 个分P，新增 ${fmtNum(added)} 条`);
      } else {
        const { cid, list } = BDA.parseXML(text);
        const existing = cid ? await db.getVideo(cid) : null;
        const name = f.name.replace(/\.xml$/i, '');
        const meta = existing || {
          cid: cid || -Date.now(), groupKey: `import-${cid || Date.now()}`, groupTitle: name, kind: 'import',
          page: 1, part: name, duration: 0, pubTs: 0, partsTotal: 1,
        };
        const r = await db.merge(meta, list, '导入 XML');
        results.push(`${f.name}：${existing ? '合并进已有存档' : '新建存档'}，新增 ${fmtNum(r.added)} 条`);
      }
    } catch (err) {
      results.push(`${f.name}：导入失败 — ${err.message}`);
    }
  }
  await renderLibrary();
  alert(results.join('\n'));
});


// ───────────── 设置 ─────────────

const form = $('#settingsForm');
const areaLabel = (v) => (v >= 1 ? '全屏' : `上 ${Math.round(v * 100)}%`);
function fillSettings(s) {
  for (const el of form.elements) {
    if (!el.name) continue;
    if (el.type === 'checkbox') el.checked = !!s[el.name];
    else el.value = s[el.name];
  }
  $('#s-area-out').textContent = areaLabel(s.area);
}
$('#s-area').addEventListener('input', (e) => ($('#s-area-out').textContent = areaLabel(Number(e.target.value))));
$('#settingsBtn').addEventListener('click', () => { fillSettings(BDA.loadSettings()); $('#settings').showModal(); });
$('#resetSettings').addEventListener('click', () => fillSettings(BDA.DEFAULTS));
$('#saveSettings').addEventListener('click', () => {
  const s = BDA.loadSettings();
  for (const el of form.elements) {
    if (!el.name) continue;
    if (el.type === 'checkbox') s[el.name] = el.checked;
    else if (el.type === 'number' || el.type === 'range') s[el.name] = Number(el.value) || BDA.DEFAULTS[el.name];
    else s[el.name] = el.value;
  }
  BDA.saveSettings(s);
  $('#settings').close();
});

// ───────────── 启动 ─────────────

if (params.get('q')) $('#search').value = params.get('q');
renderLibrary();
checkLogin();
BDA.jobs.get().then(onJobState);
